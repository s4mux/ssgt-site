# ssgt-site
In diesem Repo ist die [Jekyll](http://jekyllrb.com) basierte Website der [Sportschützen Giffers-Tentlingen](http://ssgt.ch) gespeichert. Als Basis für den Aufbau und das Design der Site diente [Swift](https://github.com/pranavrajs/swift/).
